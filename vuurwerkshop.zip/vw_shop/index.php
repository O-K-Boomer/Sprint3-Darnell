<?php

?>
<!DOCTYPE html>
    <html>
        <!-- Head -->
      <head>
          <title>Yu Hamboom</title>
          <meta char="utf-8">
          <link rel="stylesheet" href="css/yuhamboom.css">
        </head>
        
        <!-- PHP -->
        <?php
        include "php/vuurwerk.php";
        ?>
            <!-- Header -->
            <header>
                
            <!-- Website Banner-->
                 <div class="wrap">
                  <img src="vw_images/logo_yuhamboom2.png">
                 </div> 
                
                <!-- Navigation Bar -->
                <nav class="navbar">
                    <a href="index.php">Home</a>
                    <div class="dropdown">
                      <button class="dropbtn">Assortiment 
                        <i class="fa fa-caret-down"></i>
                      </button>
                      <div class="dropdown-content">
                        <a href="index.php">Compleet Assortiment</a>
                        <a href="knal.php">Knalvuurwerk</a>
                        <a href="sier.php">Siervuurwerk</a>
                      </div>
                    </div>
                    <a href="#home">Contact Info</a>
                    <div class="topnav">
                        <input type="text" placeholder="Search...">
                    </div>
                  </nav>
             
            </header>

        <!-- Body -->
        <body>   
            <h1>Welkom op Vuurwerk webshop Yu Hamboom!</h1>
            
            <!-- Grid with products -->
              <?php
                Assortiment($conn, $compleet);
              ?> 
              

        </body>
      <!-- Footer-->
        <footer>
           <h2>Meer binnenkort in ons assortiment verkrijgbaar!</h2>   
        </footer>
</html>
