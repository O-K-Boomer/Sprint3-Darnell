<?php
include "afspraken.php";

insert($connb);
printTable($connb);
?>