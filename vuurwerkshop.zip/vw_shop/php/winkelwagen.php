<?php
$id = $_GET['id'];
$aantal = $_POST['aantal'];
$servername = "localhost";
$username = "root";
$password = "";
$db = "vuurwerk";
$query = "UPDATE product SET voorraad = voorraad - $aantal WHERE naam = '$id';";

include "vuurwerk.php";

    $result = $conn->query($query);
    Winkeladd($conn, $id);
    header('Location: ' . $_SERVER['HTTP_REFERER']);
?>