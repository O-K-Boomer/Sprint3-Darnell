<?php

?>
<!DOCTYPE html>
    <html>
        <!-- Head -->
      <head>
          <title>Yu Hamboom</title>
          <meta char="utf-8">
          <link rel="stylesheet" href="css/yuhamboom.css">
        </head>
        
        <!-- PHP -->
        <?php
        include "php/vuurwerk.php";
        ?>
            <!-- Header -->
            <header>
                
            <!-- Website Banner-->
                 <div class="wrap">
                  <img src="vw_images/logo_yuhamboom2.png">
                 </div> 
                
                <!-- Navigation Bar -->
                <nav class="navbar">
                    <a href="index.php">Home</a>
                    <div class="dropdown">
                      <button class="dropbtn">Assortiment 
                        <i class="fa fa-caret-down"></i>
                      </button>
                      <div class="dropdown-content">
                        <a href="index.php?categorie=Compleet">Compleet Assortiment</a>
                        <a href="index.php?categorie=Knalvuurwerk">Knalvuurwerk</a>
                        <a href="index.php?categorie=Siervuurwerk">Siervuurwerk</a>
                      </div>
                    </div>
                  
                </nav>
             
            </header>

        <!-- Body -->
        <body>   
            <h1>Welkom op onze vuurwerk-webshop: Yu Hamboom. Wij hebben vuurwerk, jij zorgt voor de knallen!</h1>
            
            <!-- Grid with products -->
              <?php
                Assortiment($conn, $_GET['categorie']); 
              ?> 
              

        </body>
      <!-- Footer-->
        <footer>
           <h2>Meer vuurwerk binnenkort in ons assortiment verkrijgbaar!</h2>   
        </footer>
</html>
