<?php
session_start();
//Auteur: Darnell Wilbrink

//Initilisatie
$servername = "localhost";
$username = "root";
$password = "";
$db = "vuurwerk";

//connection to the database  
try {
    $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

/*
    if (!isset($_SESSION['winkelmandje'])) {
    $_SESSION['winkelmandje'] = array();
    }
*/

//function to print gridblocks with the information

function Assortiment($conn, &$cat)     {
    //fetching and printing table
    if($cat == 'Compleet'){
        $result = $conn->query("SELECT * FROM product");
    }
    elseif ($cat == ''){
        $result = $conn->query("SELECT * FROM product");
    }

    else {
        $result = $conn->query("SELECT * FROM product WHERE categorie = '$cat'");
    } 
    $datab = $result->fetchAll(PDO::FETCH_ASSOC);

    echo "<div class='grid-container'>";
    foreach($datab as $row) {
        echo "<div class='grid-item'>";
        echo "<h3>$row[naam]</h3><br><br>";
        echo "<img src='$row[url_img]'><br><br>";
        echo "<h3>€ $row[prijs]</h3>";
        echo "<h3>Voorraad: $row[voorraad]</h3>";
        echo "<form action='' method='post'><input type='number' value='1' name='aantal'><br><br><input type='submit' class='bttn' value='Bestellen'></form></div>";
        
    }
    echo "</div>";
}

?>